<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterUser($data){
            $query = "INSERT INTO user(user_lname,user_fname,user_age,user_gender,user_address, user_contact,user_email,user_password, active) VALUES(?,?,?,?,?,?,?,?,?);";
            $this->crud->Insert($query,$data);
        }
        //user INFO
        public function GetUserInfo($data){
            $query = "SELECT * FROM user WHERE active=? AND user_email=?";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        //UPDATE
        public function Updateuser($data){
            $query = "UPDATE user set user_lname=?, user_fname=?, user_age=?, user_gender=?, user_address=?, user_contact=?, aboutme=?, user_img=? where user_id=?";
            $this->crud->Update($query,$data);

        }
        //GET ORGANIZATION
        public function GetOrganization(){
            $query = "SELECT * FROM organization";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetOrganizationByID($data){
            $query = "SELECT * FROM organization WHERE org_id=?";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        //Validate Join Organization
        public function ValidateJoinOrganization($data){
            $query = "SELECT * FROM user_organization WHERE u_org_idno=? and u_org_code=? and user_id=? and org_id=?";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        public function GetCOMember($org_id){
            $query = "SELECT u.*, o.*, uo.* FROM user_organization uo, user u, organization o WHERE uo.user_id=u.user_id and uo.org_id=o.org_id and o.org_id=$org_id";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        //CHANGE EMAIL OR PASSWORD
        public function ChangeEmail($table,$data){
            $query = "UPDATE $table set user_email=? where user_id=?";
            $this->crud->Update($query,$data);

        }
        public function ChangePassword($table,$data){
            $query = "UPDATE $table set user_password=? where user_id=?";
            $this->crud->Update($query,$data);

        }
        //user Email
        public function CheckEmail($data){
            $check=NULL;
            $query = "SELECT * FROM user where user_email=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        public function CheckPassword($data){
            $check=NULL;
            $query = "SELECT * FROM user where user_id=? and user_password=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        public function getUserIDByEmail($data){
            $id=0;
            $query = "SELECT * FROM user where user_email=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $id = $row['user_id'];
            }
            return $id;
        }
        public function getUserNameByID($data){
            $name=null;
            $query = "SELECT * FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $name = $row['user_fname'];
            }
            return $name;
        }
        public function getUserImgByEmail($data){
            $img=null;
            $query = "SELECT * FROM user where user_email=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $img = $row['user_img'];
            }
            else $img=null;
            return $img;
        }
       
        public function ValidateUserLogin($data){
            $query = "SELECT * FROM user where user_email=? and user_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function UpdateOnlineUser($username,$line){
            $query = "UPDATE user SET active = $line wHERE user_email='$username'";
            $this->crud->Update($query,array($username,$line));
        }
        //LOGOUT
        public function Logout(){
            if(isset($_COOKIE['email'])){
                $this->UpdateOnlineUser($_COOKIE['email'],0);
                setcookie("email",$_COOKIE['email'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }

        
	}
?>