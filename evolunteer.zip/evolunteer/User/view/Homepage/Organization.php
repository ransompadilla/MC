<section class="features" id="features">
      <div class="container">
        <div class="section-heading text-center">
          <h2>Organization</h2>
          <p class="text-muted">Choose your organization</p>
          <hr>
        </div>
        <div class="row">
          <div class="col-lg-12 my-auto">
            <div class="container-fluid">
              <div class="row">
              <?php
                foreach ($org as $o) {
                  echo '
                    
                      <div class="col-lg-4">
                        <div class="feature-item">
                        <a href="#organization'.$o['org_id'].'" data-toggle="modal">
                          <img src="'.$o['org_img'].'" width="250">
                        </a>
                          <p class="text-muted">'.$o['org_desc'].'</p>
                        </div>
                      </div>
                  ';
                }
              ?>
              
                    </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php
    	for($i=0; $i<=(count($org)); $i++){
    		$v = $this->model->GetOrganizationByID(array($i));
    		echo '
    			<div class="modal fade" id="organization'.$i.'" tabindex="-1" role="dialog" aria-hidden="true">
		            <div class="modal-dialog">
		              <div class="modal-content">
		                <div class="close-modal" data-dismiss="modal">
		                  <div class="lr">
		                    <div class="rl"></div>
		                  </div>
		                </div>
		                      <div class="modal-body">
		                      	<h3><img src="'.$v['org_img'].'" width="100" /> &nbsp;&nbsp;ACCOUNT LOGIN </h3>
		                        <!-- Project Details Go Here -->
		                       <form method="post">
		                       <input type="hidden" name="org_id" value="'.$v['org_id'].'">
		                       <input type="hidden" name="user_id" value="'.$id.'">
		                       <input type="text" name="idno" placeholder="ID-NUMBER: " class="form-control"><br>
		                       <input type="text" name="org_code" placeholder="'.$v['org_name'].'-CODE: " class="form-control"><br>
		                       <button type="submit" name="join_organization" style="width: 100%;" class="btn btn-primary">JOIN</button>
		                       </form>
		                       <!-- <button class="btn btn-primary" data-dismiss="modal" type="button" style="width: 100%;">
		                    <i class="fa fa-times"></i>
		                    Close </button> -->
		                      </div>
		                    </div>
		            </div>
		          </div>
    		';
    	}
    ?>
    