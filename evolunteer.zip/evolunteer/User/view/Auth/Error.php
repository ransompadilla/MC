<div class="page-404">
    <!-- <p class="text-404">ERROR!</p> -->
    <h2>ERROR!</h2>
    <h2>Aww Snap!</h2>
    <p>Something went wrong or that page doesn’t exist yet. <br><a href="index.php">Return Home</a></p>
  </div>
  <div class="credits">
    <!-- 
        All the links in the footer should remain intact. 
        You can delete the links only if you purchased the pro version.
        Licensing information: https://bootstrapmade.com/license/
        Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
    -->
</div>