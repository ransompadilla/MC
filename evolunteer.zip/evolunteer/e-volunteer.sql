-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2018 at 01:01 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e-volunteer`
--

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE IF NOT EXISTS `organization` (
  `org_id` int(11) NOT NULL AUTO_INCREMENT,
  `org_name` varchar(50) DEFAULT NULL,
  `org_desc` varchar(10000) DEFAULT NULL,
  `org_img` blob,
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`org_id`, `org_name`, `org_desc`, `org_img`) VALUES
(1, 'Red Cross', 'The Red Cross, born of a desire to bring assistance without discrimination to the wounded on the bat', 0x696d672f6f72675f6c6f676f2f72656463726f73732d6c6f676f2e706e67),
(2, 'Peace Corps', 'is a volunteer program run by the United States government.', 0x696d672f6f72675f6c6f676f2f70656163652d636f7270732d6c6f676f2e706e67),
(3, 'Habitat for Humanity', 'Habitat for Humanity International, generally referred to as Habitat for Humanity or simply Habitat, is an international, non-governmental, and nonprofit organization, which was founded in 1976', 0x696d672f6f72675f6c6f676f2f686162697461742d6c6f676f2e706e67),
(4, 'VolunteerMatch', 'Impact Online, also known as VolunteerMatch, is an American nonprofit organization best known for its web services, which aim to strengthen communities by making it easier for people to find good causes', 0x696d672f6f72675f6c6f676f2f566f6c756e746565724d617463682d6c6f676f2e6a7067),
(5, 'United Nations Volunteers', 'The United Nations Volunteers programme is a United Nations organization that contributes to peace and development through volunteerism worldwide', 0x696d672f6f72675f6c6f676f2f756e2d766f6c756e746565722d6c6f676f2e706e67),
(6, 'International Volunteer HQ', 'International Volunteer HQ is a New Zealand volunteer travel company founded by Daniel Radcliffe in 2007. Company founder Radcliffe says IVHQ has placed more than 50,000 international volunteers on community projects in over 32 countries', 0x696d672f6f72675f6c6f676f2f696e7465726e6174696f6e616c2d68712d6c6f676f2e706e67);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_lname` varchar(25) DEFAULT NULL,
  `user_fname` varchar(25) DEFAULT NULL,
  `user_age` int(3) DEFAULT NULL,
  `user_gender` char(1) DEFAULT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `user_contact` varchar(15) DEFAULT NULL,
  `user_img` blob,
  `user_email` varchar(50) DEFAULT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_lname`, `user_fname`, `user_age`, `user_gender`, `user_address`, `user_contact`, `user_img`, `user_email`, `user_password`, `active`) VALUES
(1, 'Carino', 'Ransom', 22, 'M', 'Biasong, Talisay City, Cebu', '09234815395', NULL, 'padillaransom@gmail.com', 'ransom', 1),
(2, 'Tecson', 'Maria Cres', 19, 'F', 'Orgello Cebu City', '09232423523', NULL, 'mctecson@gmail.com', 'tecson', 0),
(3, 'Agapay', 'Percy', 22, 'M', 'Lahug Cebu City', '09123242323', NULL, 'percy@gmail.com', 'percy', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_organization`
--

CREATE TABLE IF NOT EXISTS `user_organization` (
  `u_org_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_org_rank` varchar(50) DEFAULT NULL,
  `u_org_idno` int(11) DEFAULT NULL,
  `u_org_code` varchar(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `org_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`u_org_id`),
  KEY `user_id_cons` (`user_id`),
  KEY `org_id_cons` (`org_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_organization`
--

INSERT INTO `user_organization` (`u_org_id`, `u_org_rank`, `u_org_idno`, `u_org_code`, `user_id`, `org_id`) VALUES
(1, 'Member', 1001, 'GHE428', 1, 1),
(2, 'Leader', 1002, 'MCTEC28', 2, 1),
(3, 'Member', 1003, 'PERC42', 3, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_organization`
--
ALTER TABLE `user_organization`
  ADD CONSTRAINT `org_id_cons` FOREIGN KEY (`org_id`) REFERENCES `organization` (`org_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `user_id_cons` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
